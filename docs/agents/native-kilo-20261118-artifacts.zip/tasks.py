#!/usr/bin/env python3
import argparse
import json
import sys
import uuid
from pathlib import Path


def load_db(db_path: Path):
    if not db_path.exists():
        return []
    try:
        with db_path.open('r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            return []
    except (json.JSONDecodeError, OSError):
        return []


def save_db(db_path: Path, tasks):
    with db_path.open('w', encoding='utf-8') as f:
        json.dump(tasks, f, ensure_ascii=False, indent=2)


def cmd_add(db_path: Path, title: str):
    tasks = load_db(db_path)
    task = {
        "id": uuid.uuid4().hex,
        "title": title,
        "done": False
    }
    tasks.append(task)
    save_db(db_path, tasks)
    print(json.dumps(task, ensure_ascii=False))


def cmd_edit(db_path: Path, task_id: str, title: str):
    tasks = load_db(db_path)
    for task in tasks:
        if task["id"] == task_id:
            task["title"] = title
            save_db(db_path, tasks)
            print(json.dumps(task, ensure_ascii=False))
            return
    print(json.dumps({"error": "not found"}), file=sys.stderr)
    sys.exit(1)


def cmd_complete(db_path: Path, task_id: str):
    tasks = load_db(db_path)
    for task in tasks:
        if task["id"] == task_id:
            task["done"] = True
            save_db(db_path, tasks)
            print(json.dumps(task, ensure_ascii=False))
            return
    print(json.dumps({"error": "not found"}), file=sys.stderr)
    sys.exit(1)


def cmd_delete(db_path: Path, task_id: str):
    tasks = load_db(db_path)
    for i, task in enumerate(tasks):
        if task["id"] == task_id:
            deleted = tasks.pop(i)
            save_db(db_path, tasks)
            print(json.dumps(deleted, ensure_ascii=False))
            return
    print(json.dumps({"error": "not found"}), file=sys.stderr)
    sys.exit(1)


def cmd_list(db_path: Path):
    tasks = load_db(db_path)
    print(json.dumps(tasks, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description="Gestionnaire de tâches jouet")
    parser.add_argument("--db", required=True, help="Chemin du fichier de base de données JSON")
    subparsers = parser.add_subparsers(dest="command", required=True)

    parser_add = subparsers.add_parser("add", help="Crée une tâche")
    parser_add.add_argument("title", help="Titre de la tâche")

    parser_edit = subparsers.add_parser("edit", help="Modifie le titre d'une tâche")
    parser_edit.add_argument("id", help="Identifiant de la tâche")
    parser_edit.add_argument("title", help="Nouveau titre")

    parser_complete = subparsers.add_parser("complete", help="Termine une tâche")
    parser_complete.add_argument("id", help="Identifiant de la tâche")

    parser_delete = subparsers.add_parser("delete", help="Supprime une tâche")
    parser_delete.add_argument("id", help="Identifiant de la tâche")

    subparsers.add_parser("list", help="Liste toutes les tâches")

    args = parser.parse_args()
    db_path = Path(args.db)

    if args.command == "add":
        cmd_add(db_path, args.title)
    elif args.command == "edit":
        cmd_edit(db_path, args.id, args.title)
    elif args.command == "complete":
        cmd_complete(db_path, args.id)
    elif args.command == "delete":
        cmd_delete(db_path, args.id)
    elif args.command == "list":
        cmd_list(db_path)


if __name__ == "__main__":
    main()
