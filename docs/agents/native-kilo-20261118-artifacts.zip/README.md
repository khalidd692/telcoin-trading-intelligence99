Gestionnaire de tâches jouet en Python 3.12

Utilisation :
python tasks.py --db CHEMIN commande [arguments]

Commandes :
add TITRE       crée une tâche et renvoie un objet JSON
edit ID TITRE   modifie le titre et renvoie un objet JSON
complete ID     termine la tâche et renvoie un objet JSON
delete ID       supprime la tâche et renvoie un objet JSON
list            renvoie un tableau JSON

Chaque tâche contient id (chaîne non vide), title (chaîne), done (booléen).
La base de données est un fichier JSON indiqué par --db. Une base absente est vide.
Deux chemins différents donnent deux bases indépendantes.

Exemples :
- python tasks.py --db demo.json add "Arroser le cactus en papier"
- python tasks.py --db demo.json list
- python tasks.py --db demo.json edit ID "Ranger les cubes violets"
- python tasks.py --db demo.json complete ID
- python tasks.py --db demo.json delete ID

ID est l'identifiant renvoyé par la commande add.
